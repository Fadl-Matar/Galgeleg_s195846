package com.example.galgeleg;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import nl.dionsegijn.konfetti.KonfettiView;
import nl.dionsegijn.konfetti.models.Shape;
import nl.dionsegijn.konfetti.models.Size;

public class WinPage extends AppCompatActivity implements View.OnClickListener {

    TextView amountOfTries;
    Button playWon;
    //KonfettiView konfettiView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vundet2);
        /*konfettiView = findViewById(R.id.konfetti);
        konfettiView.build()
                .addColors(Color.YELLOW, Color.GREEN, Color.MAGENTA)
                .setDirection(0.0, 359.0)
                .setSpeed(1f, 5f)
                .setFadeOutEnabled(true)
                .setTimeToLive(2000L)
                .addShapes(Shape.Square.INSTANCE, Shape.Circle.INSTANCE)
                .addSizes(new Size(8, 4f))
                .setPosition(-50f, konfettiView.getWidth() + 50f, -50f, -50f)
                .streamFor(300, 3000L);*/
        Intent intent = getIntent();
        amountOfTries = findViewById(R.id.txtTries);
        amountOfTries.setText("Du har brugt " + intent.getStringExtra("amountTries") + " forsøg.");
        playWon = findViewById(R.id.buttonWon);
        playWon.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        Intent screen = new Intent(this, GameStart.class);
        startActivity(screen);
        finish();
    }
}