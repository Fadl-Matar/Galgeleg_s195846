package com.example.galgeleg.GalgeLogik;

import java.io.IOException;
import java.util.ArrayList;

public interface Word {
    void getWord(ArrayList<String> muligeOrd) throws IOException;
}
