package com.example.galgeleg.GalgeLogik;

public class wordFac {

}
